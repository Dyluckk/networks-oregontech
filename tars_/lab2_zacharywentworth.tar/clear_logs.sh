#!/bin/bash
rm -rf ./_logs/*
